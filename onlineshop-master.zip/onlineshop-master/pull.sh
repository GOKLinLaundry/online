git pull https://github.com/udibagas/onlineshop.git
