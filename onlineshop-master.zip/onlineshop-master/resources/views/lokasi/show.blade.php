@extends('app')

@section('content')

	<h1>Toko di: {{ $lokasi->nama }}</h1>
	<hr />

@stop