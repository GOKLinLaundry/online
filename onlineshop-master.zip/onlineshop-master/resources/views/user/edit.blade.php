@extends('app')

@section('content')

	<h1>Update Profile</h1>
	<hr />

	@include('user._form');

@stop