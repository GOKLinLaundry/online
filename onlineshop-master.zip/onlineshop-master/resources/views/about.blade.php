@extends('app')

@section('content')
	this is about
@stop