<img src="/uploads/{{ $product->image }}" alt="{{ $product->name }}" class="img-thumbnail" />
<br /><br />