<div class="box grid_12">
	<p>
	Berhasil mereset password ! <span style="font-weight: bold;"><?php echo $username; ?></span> mempunyai password berikut :<br/>
	<span style="font-size: 45; font-wight: bold;"><?php echo $password; ?></span>
	<br/>
	Peringatan ! password ini case sensitive, jadi huruf besar dan kecil berbeda !
	</p>
</div>